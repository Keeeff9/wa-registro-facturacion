from django.contrib import admin
from .models import Mesa
# Register your models here.

admin.site.register(Mesa)

