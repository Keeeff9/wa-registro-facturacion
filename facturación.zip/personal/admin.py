from django.contrib import admin
from .models import Mesero
# Register your models here.

admin.site.register(Mesero)
